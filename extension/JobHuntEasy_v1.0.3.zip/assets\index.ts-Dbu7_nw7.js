import{s as z,g as S}from"./utils-DQRLEex7.js";document.documentElement.setAttribute("data-job-hunt-easy-installed","true");const g=new Map,x=new Map;let y=!0;chrome.storage.sync.get("settings",e=>{e.settings&&(y=e.settings.enabled??!0),y?E(document.body):v()});chrome.storage.onChanged.addListener((e,n)=>{var t;n==="sync"&&e.settings&&(y=((t=e.settings.newValue)==null?void 0:t.enabled)??!0,y?E(document.body):v())});function v(){document.querySelectorAll("[data-job-hunt-easy-wrapper]").forEach(e=>e.remove()),document.body.querySelectorAll("[data-job-hunt-easy-attached]").forEach(e=>{delete e.dataset.jobHuntEasyAttached}),g.clear(),x.clear()}const R=setInterval(()=>{chrome.runtime.sendMessage({type:"KEEP_ALIVE"}).catch(()=>{console.debug("[Job Hunt Easy] Extension context lost. Cleaning up zombie UI."),clearInterval(R),v(),C.disconnect()})},2e4);let w=null;const C=new MutationObserver(e=>{var t;let n=!1;for(const i of e){for(const o of i.addedNodes)if(!(o.nodeType!==Node.ELEMENT_NODE||(t=o.dataset)!=null&&t.jobHuntEasyWrapper)){n=!0;break}if(n)break}n&&(w&&clearTimeout(w),w=setTimeout(()=>{E(document.body)},300))});C.observe(document.body,{childList:!0,subtree:!0});function E(e){const n=e.querySelectorAll('input[type="text"], input[type="email"], input[type="tel"], input:not([type]), textarea'),t=e;M(t)&&k(t)&&L(t),n.forEach(i=>{k(i)&&L(i)})}function M(e){return e instanceof HTMLTextAreaElement?!0:e instanceof HTMLInputElement?["text","email","tel",""].includes(e.type):!1}function k(e){var l;if(!y||!M(e)||e.dataset.jobHuntEasyAttached||e.offsetWidth===0||e.offsetHeight===0||e.style.display==="none"||e.style.visibility==="hidden"||"checkVisibility"in e&&!e.checkVisibility()||e.offsetWidth<120||e instanceof HTMLInputElement&&["password","hidden","checkbox","radio","file","submit","button","image","reset","color","date","datetime-local","month","number","range","search","time","url","week"].includes(e.type)||e.closest('nav, header, [role="navigation"], [role="banner"], [role="toolbar"], [role="search"], [role="menubar"], [role="menu"], [role="dialog"], .nav, .navbar, .header, .toolbar, .search-bar, .search-form'))return!1;const t=((l=e.getAttribute("aria-label"))==null?void 0:l.toLowerCase())??"",i=(e.placeholder||"").toLowerCase();if(["search","filter","find","type a message","write a comment","add a comment","say something"].some(c=>t.includes(c)||i.includes(c)))return!1;const s=H(e);if(!s||s.length<10)return!1;const a=s.toLowerCase();return!(a.includes("search")||a.includes("filter")||a==="name")}function H(e){var o,s,a,l,c,u,f;let n="";if(e.id){const r=document.querySelector(`label[for="${CSS.escape(e.id)}"]`);r!=null&&r.innerText.trim()&&(n=r.innerText.trim())}if(!n){const r=e.closest("label");r!=null&&r.innerText.trim()&&(n=r.innerText.trim())}if(!n){const r=e.getAttribute("aria-label");r!=null&&r.trim()&&(n=r.trim())}if(!n){const r=e.getAttribute("aria-labelledby");if(r){const d=document.getElementById(r);d!=null&&d.innerText.trim()&&(n=d.innerText.trim())}}if(!n){const r=e.previousElementSibling;(o=r==null?void 0:r.innerText)!=null&&o.trim()&&(n=r.innerText.trim())}if(!n){const r=(l=(a=(s=e.parentElement)==null?void 0:s.firstChild)==null?void 0:a.textContent)==null?void 0:l.trim();r&&(n=r.trim())}if(!n){let r=e;for(let d=0;d<4&&!(!r||r===document.body);d++){let p=r.previousElementSibling;for(;p;){const m=((c=p.innerText)==null?void 0:c.trim())||((u=p.textContent)==null?void 0:u.trim());if(m&&m.length>2){n=m;break}p=p.previousElementSibling}if(n)break;r=r.parentElement}}if(!n){let r=e;for(;r;)if(r=r.previousSibling,r&&r.nodeType===Node.TEXT_NODE){const d=(f=r.textContent)==null?void 0:f.trim();if(d&&d.length>2){n=d;break}}}const t=e.placeholder||"";let i=n;return t&&t.trim()&&t!==n&&(i?i=`${i} (Hint: ${t.trim()})`:i=t.trim()),z(i)}function L(e){var f,r;e.dataset.jobHuntEasyAttached="true";const n=S(e);g.set(n,e);const t=document.createElement("div");t.dataset.jobHuntEasyWrapper="true",t.style.cssText=`
    position: fixed;
    z-index: 2147483647;
    pointer-events: none;
    transition: opacity 0.15s ease-in-out;
  `;const i=t.attachShadow({mode:"open"}),o=document.createElement("style");o.textContent=`
    :host { all: initial; }
    .job-hunt-easy-btn {
      pointer-events: all;
      display: inline-flex;
      align-items: center;
      gap: 4px;
      padding: 3px 8px;
      background: #6366f1;
      color: white;
      border: none;
      border-radius: 6px;
      font-size: 11px;
      font-family: system-ui, sans-serif;
      font-weight: 500;
      cursor: pointer;
      box-shadow: 0 1px 4px rgba(99,102,241,0.35);
      transition: opacity 0.15s, transform 0.1s;
      white-space: nowrap;
      line-height: 1;
    }
    .job-hunt-easy-btn:hover { opacity: 0.9; transform: scale(1.03); }
    .job-hunt-easy-btn:disabled { opacity: 0.6; cursor: wait; }
    .job-hunt-easy-btn.loading::after {
      content: '';
      width: 10px;
      height: 10px;
      border: 2px solid rgba(255,255,255,0.4);
      border-top-color: white;
      border-radius: 50%;
      animation: spin 0.6s linear infinite;
    }
    @keyframes spin { to { transform: rotate(360deg); } }
  `;const s=document.createElement("button");s.className="job-hunt-easy-btn";const a=e instanceof HTMLInputElement||e instanceof HTMLTextAreaElement?!!((f=e.value)!=null&&f.trim()):!!((r=e.textContent)!=null&&r.trim());s.innerHTML=a?"<span>↻</span> Regenerate":"<span>✦</span> Fill with AI",s.setAttribute("aria-label","Fill this field with AI using your resume"),s.addEventListener("click",()=>{var b,h;const d=H(e);if(!d)return;const p=e instanceof HTMLInputElement||e instanceof HTMLTextAreaElement?!!((b=e.value)!=null&&b.trim()):!!((h=e.textContent)!=null&&h.trim());s.disabled=!0,s.classList.add("loading"),s.innerHTML="<span></span> Generating...";const m=B();chrome.runtime.sendMessage({type:"FILL_REQUEST",payload:{question:d,fieldId:n,pageUrl:window.location.href,pageTitle:document.title,isRegeneration:p,jobContext:m}}).catch(()=>{s.disabled=!1,s.classList.remove("loading"),s.innerHTML=p?"<span>↻</span> Regenerate":"<span>✦</span> Fill with AI",A("Extension was updated. Please refresh this page (F5).","info"),v()})}),i.appendChild(o),i.appendChild(s),j(t,e),document.body.appendChild(t),x.set(n,t);const l=P(t,e);window.addEventListener("scroll",l,{passive:!0,capture:!0}),window.addEventListener("resize",l,{passive:!0});const c=new ResizeObserver(()=>l());c.observe(e),e.dataset.jobHuntEasyButtonId=n,t._jobHuntEasyButton=s,t._fieldId=n;const u=new MutationObserver(()=>{document.contains(e)||(t.remove(),g.delete(n),x.delete(n),window.removeEventListener("scroll",l,{capture:!0}),window.removeEventListener("resize",l),c.disconnect(),u.disconnect())});u.observe(document.body,{childList:!0,subtree:!0})}function P(e,n){let t=!1;return()=>{t||(t=!0,requestAnimationFrame(()=>{j(e,n),t=!1}))}}function j(e,n){const t=n.getBoundingClientRect();if(t.height===0||t.width===0||t.bottom<0||t.top>window.innerHeight||t.right<0||t.left>window.innerWidth){e.style.opacity="0",e.style.pointerEvents="none";return}e.style.opacity="1",e.style.pointerEvents="none";const i=90,o=22,s=4;t.height<45?(e.style.top=`${t.top+(t.height-o)/2}px`,e.style.left=`${t.right+s}px`):(e.style.top=`${t.top+s}px`,e.style.left=`${t.right-i-s}px`)}chrome.runtime.onMessage.addListener(e=>{var n;if(e.type==="STREAM_CHUNK"){const{fieldId:t,chunk:i}=e.payload,o=g.get(t);if(!o)return;if(o instanceof HTMLTextAreaElement||o instanceof HTMLInputElement){const s=(n=Object.getOwnPropertyDescriptor(window[o.tagName==="INPUT"?"HTMLInputElement":"HTMLTextAreaElement"].prototype,"value"))==null?void 0:n.set;s?s.call(o,o.value+i):o.value+=i,o.dispatchEvent(new Event("input",{bubbles:!0})),o.dispatchEvent(new Event("change",{bubbles:!0}))}else o.isContentEditable&&(o.textContent+=i,o.dispatchEvent(new InputEvent("input",{bubbles:!0})),o.dispatchEvent(new Event("change",{bubbles:!0})))}if(e.type==="STREAM_DONE"){const{fieldId:t}=e.payload;I(t,!0)}if(e.type==="ERROR"){const{fieldId:t,message:i,code:o}=e.payload;I(t,!1),o==="DAILY_LIMIT_REACHED"?U():o==="UPGRADE_REQUIRED"?F():o==="API_RATE_LIMITED"||i.includes("rate limit")||i.includes("429")?A("Model experiencing high load. Try waiting a moment, switch to a different model, or upgrade to Pro for priority access.","info"):console.warn("[Job Hunt Easy] Suppressed error toast:",o,i)}});function I(e,n=!1){var l,c;const t=x.get(e),i=g.get(e);if(!(t!=null&&t._jobHuntEasyButton)||!i)return;const o=t._jobHuntEasyButton,a=(i instanceof HTMLInputElement||i instanceof HTMLTextAreaElement?!!((l=i.value)!=null&&l.trim()):!!((c=i.textContent)!=null&&c.trim()))?"<span>↻</span> Regenerate":"<span>✦</span> Fill with AI";n?(o.innerHTML='<span style="color: #4ade80;">✓</span> Done',o.classList.remove("loading"),setTimeout(()=>{o.disabled=!1,o.innerHTML=a},2e3)):(o.disabled=!1,o.classList.remove("loading"),o.innerHTML=a)}function B(){var s,a,l,c,u,f,r,d,p,m,b,h;const e=window.location.hostname;let n=e.replace("www.","");e.includes("linkedin")?n="LinkedIn":e.includes("greenhouse")?n="Greenhouse":e.includes("lever")?n="Lever":e.includes("workday")?n="Workday":e.includes("ashby")&&(n="Ashby");let t="",i="";const o=document.title||"";if(n==="LinkedIn"&&o.includes(" | ")){const T=o.split(" | ");i=(s=T[0])==null?void 0:s.trim(),t=(a=T[1])==null?void 0:a.trim()}else n==="Greenhouse"?(t=((c=(l=document.querySelector(".company-name"))==null?void 0:l.textContent)==null?void 0:c.trim())||"",i=((f=(u=document.querySelector(".app-title"))==null?void 0:u.textContent)==null?void 0:f.trim())||""):n==="Lever"?(i=((d=(r=document.querySelector(".posting-headline h2"))==null?void 0:r.textContent)==null?void 0:d.trim())||"",t=((p=o.split("-")[0])==null?void 0:p.trim())||""):(i=((b=(m=document.querySelector("h1"))==null?void 0:m.textContent)==null?void 0:b.trim())||"",t=((h=o.split("-")[0])==null?void 0:h.trim())||"");return i.length>200&&(i=i.slice(0,200)),t.length>200&&(t=t.slice(0,200)),{companyName:t,roleTitle:i,platform:n}}function A(e,n="info"){var c;(c=document.getElementById("job-hunt-easy-toast"))==null||c.remove();const t=document.createElement("div");t.id="job-hunt-easy-toast";const i="rgba(17, 17, 27, 0.95)",o=n==="info"?"rgba(99, 102, 241, 0.4)":"rgba(239, 68, 68, 0.4)",s=n==="info"?"#818cf8":"#f87171";t.style.cssText=`
    position: fixed; bottom: 24px; right: 24px;
    background: ${i}; color: #e0e4f5;
    padding: 14px 20px; border-radius: 12px;
    font-family: system-ui, -apple-system, sans-serif; font-size: 13px;
    line-height: 1.5;
    z-index: 2147483647;
    box-shadow: 0 8px 32px rgba(0,0,0,0.4);
    border: 1px solid ${o};
    backdrop-filter: blur(12px);
    max-width: 360px;
    animation: jheFadeIn 0.3s ease-out;
  `;const a=document.createElement("style");a.textContent="@keyframes jheFadeIn { from { opacity: 0; transform: translateY(8px); } to { opacity: 1; transform: translateY(0); } }",t.appendChild(a);const l=document.createElement("div");l.style.cssText="display: flex; align-items: flex-start; gap: 10px;",l.innerHTML=`
    <span style="color: ${s}; font-size: 16px; flex-shrink: 0; margin-top: 1px;">⚡</span>
    <span>${e}</span>
  `,t.appendChild(l),document.body.appendChild(t),setTimeout(()=>{t.style.transition="opacity 0.3s, transform 0.3s",t.style.opacity="0",t.style.transform="translateY(8px)",setTimeout(()=>t.remove(),300)},6e3)}function F(){if(document.getElementById("job-hunt-easy-pro-modal"))return;const e=document.createElement("div");e.id="job-hunt-easy-pro-modal",e.style.cssText=`
    position: fixed; top: 0; left: 0; width: 100vw; height: 100vh;
    background: rgba(0,0,0,0.6); backdrop-filter: blur(4px);
    display: flex; align-items: center; justify-content: center;
    z-index: 2147483647; font-family: system-ui, -apple-system, sans-serif;
  `;const n=e.attachShadow({mode:"open"});n.innerHTML=`
    <style>
      .modal {
        background: #fff; width: 420px; border-radius: 16px;
        padding: 30px; box-shadow: 0 20px 40px rgba(0,0,0,0.2);
        position: relative; animation: slideUp 0.3s cubic-bezier(0.16, 1, 0.3, 1);
      }
      @keyframes slideUp { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
      .close {
        position: absolute; top: 16px; right: 16px; background: none; border: none;
        font-size: 20px; cursor: pointer; color: #9ca3af;
      }
      .close:hover { color: #374151; }
      .icon {
        width: 48px; height: 48px; border-radius: 14px; background: #eef2ff;
        color: #4f46e5; display: flex; align-items: center; justify-content: center;
        margin: 0 auto 16px; font-weight: 800; font-size: 20px;
      }
      h2 { margin: 0 0 12px; font-size: 22px; color: #111827; text-align: center; line-height: 1.3; }
      p { margin: 0; color: #4b5563; font-size: 14px; line-height: 1.6; text-align: center; }
      .features { background: #f3f4f6; border-radius: 12px; padding: 16px; margin: 22px 0; color: #374151; font-size: 14px; line-height: 1.8; }
      .features strong { color: #111827; }
      .upgrade-btn {
        display: block; width: 100%; padding: 14px; background: #4f46e5;
        color: white; border: none; border-radius: 8px; font-size: 15px;
        font-weight: 700; cursor: pointer; text-align: center; text-decoration: none;
      }
      .upgrade-btn:hover { background: #4338ca; }
      .later-btn {
        display: block; width: 100%; padding: 12px; background: none;
        border: none; color: #6b7280; font-size: 14px; margin-top: 8px;
        cursor: pointer; text-align: center;
      }
    </style>
    <div class="modal">
      <button class="close">x</button>
      <div class="icon">Pro</div>
      <h2>Premium models are included with Pro</h2>
      <p>Upgrade to unlock smarter models and keep filling applications without the free daily cap.</p>
      <div class="features">
        <div><strong>Unlimited</strong> autofill sessions</div>
        <div><strong>Premium</strong> AI models</div>
        <div><strong>Priority</strong> job application workflow</div>
      </div>
      <a href="https://job-hunt-easy-dashboard.vercel.app/pricing" target="_blank" class="upgrade-btn">
        View Pro pricing
      </a>
      <button class="later-btn">Keep using free model</button>
    </div>
  `,document.body.appendChild(e);const t=n.querySelector(".close"),i=n.querySelector(".later-btn"),o=n.querySelector(".upgrade-btn"),s=()=>e.remove();t.onclick=s,i.onclick=s,o.onclick=s}function U(){if(document.getElementById("job-hunt-easy-limit-modal"))return;const e=document.createElement("div");e.id="job-hunt-easy-limit-modal",e.style.cssText=`
    position: fixed; top: 0; left: 0; width: 100vw; height: 100vh;
    background: rgba(0,0,0,0.6); backdrop-filter: blur(4px);
    display: flex; align-items: center; justify-content: center;
    z-index: 2147483647; font-family: system-ui, -apple-system, sans-serif;
  `;const n=e.attachShadow({mode:"open"}),t=`
    <style>
      .modal {
        background: #fff; width: 440px; border-radius: 16px;
        padding: 32px; box-shadow: 0 20px 40px rgba(0,0,0,0.2);
        position: relative; animation: slideUp 0.3s cubic-bezier(0.16, 1, 0.3, 1);
      }
      @keyframes slideUp { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
      .close {
        position: absolute; top: 16px; right: 16px; background: none; border: none;
        font-size: 20px; cursor: pointer; color: #9ca3af;
      }
      .close:hover { color: #374151; }
      .emoji { font-size: 40px; text-align: center; margin-bottom: 16px; }
      h2 { margin: 0 0 12px; font-size: 22px; color: #111827; text-align: center; line-height: 1.3; }
      .math-box {
        background: #f3f4f6; border-radius: 12px; padding: 16px;
        margin: 24px 0; font-size: 14px; color: #4b5563; line-height: 1.6;
      }
      .math-box strong { color: #111827; }
      .stats {
        display: flex; align-items: center; gap: 8px; margin-bottom: 24px;
        color: #059669; font-weight: 500; font-size: 14px; justify-content: center;
      }
      .upgrade-btn {
        display: block; width: 100%; padding: 14px; background: #2563eb;
        color: white; border: none; border-radius: 8px; font-size: 16px;
        font-weight: 600; cursor: pointer; text-align: center; text-decoration: none;
        transition: background 0.2s;
      }
      .upgrade-btn:hover { background: #1d4ed8; }
      .later-btn {
        display: block; width: 100%; padding: 12px; background: none;
        border: none; color: #6b7280; font-size: 14px; margin-top: 8px;
        cursor: pointer; text-align: center;
      }
      .later-btn:hover { color: #374151; text-decoration: underline; }
    </style>
    <div class="modal">
      <button class="close">×</button>
      <div class="emoji">🎉</div>
      <h2>5 applications done —<br/>you're on fire!</h2>
      
      <div class="math-box">
        <strong>More applications = More interviews.</strong><br/>
        Less applications = Less interviews.<br/><br/>
        In the same time you'd fill 1 form manually, Pro users complete <strong>6+ applications</strong>.<br/>
        Upgrade now and maximize every minute of your job search.
      </div>
      
      <div class="stats">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"></polyline><polyline points="17 6 23 6 23 12"></polyline></svg>
        30+ applications/day with Pro vs 5 on Free
      </div>
      
      <a href="https://job-hunt-easy-dashboard.vercel.app/pricing" target="_blank" class="upgrade-btn">
        Upgrade to Pro — Unlimited Applications →
      </a>
      <button class="later-btn">Fill Manually (4x fewer applications per hour)</button>
    </div>
  `;n.innerHTML=t,document.body.appendChild(e);const i=n.querySelector(".close"),o=n.querySelector(".later-btn"),s=n.querySelector(".upgrade-btn"),a=()=>e.remove();i.onclick=a,o.onclick=a,s.onclick=a}export{H as extractQuestion};
